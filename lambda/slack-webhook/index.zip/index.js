const Slack = require('slack-node');
const webhookUri = process.env.SLACK_WEBHOOK_URL;

exports.handler = (event, context) => {
    console.log("Event: " + JSON.stringify(event));
    const message = event['Records'][0]['Sns']['Message'];
    console.log("Message: " + message);

    slack = new Slack();
    slack.setWebhook(webhookUri);

    slack.webhook({
      channel: process.env.SLACK_CHANNEL,
      username: process.env.SLACK_USER,
      text: message
    }, function(err, response) {
      console.log("Responce: " + response);
      context.done();
    });
};